"""Read-only WebSocket fan-out for validated provider events; does not fetch data."""
import asyncio

class MarketStreamManager:
    def __init__(self):
        self.clients = set()
        self.latest = {}
        self._lock = asyncio.Lock()

    async def connect(self, websocket):
        await websocket.accept()
        async with self._lock:
            self.clients.add(websocket)

    async def disconnect(self, websocket):
        async with self._lock:
            self.clients.discard(websocket)

    async def publish(self, tick):
        self.latest[tick.symbol] = tick
        payload = {
            "type": "market_tick", "symbol": tick.symbol,
            "last_price": tick.last_price,
            "exchange_timestamp": tick.exchange_timestamp.isoformat(),
            "received_timestamp": tick.received_timestamp.isoformat(),
            "source": tick.source, "delayed": tick.delayed,
            "freshness": tick.freshness, "read_only": True
        }
        async with self._lock:
            clients = list(self.clients)
        for ws in clients:
            try:
                await ws.send_json(payload)
            except Exception:
                await self.disconnect(ws)

    def status(self):
        return {"connected_clients": len(self.clients), "symbols_cached": len(self.latest)}
