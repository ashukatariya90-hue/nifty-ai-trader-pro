# NIFTY AI TRADER PRO V7.0.1 — Paper Ledger Backup

- Adds a Backup tab to the Android application.
- Exports the local `paper_ledger` positions and history as versioned JSON.
- Restores only recognised schema version 1 backups after structural and value validation.
- Restore writes both ledger arrays together using SharedPreferences `commit()` and recreates the Activity to reload state.
- Restore replaces the current local positions/history; it does not merge them.
- Backup excludes API settings, credentials, market CSV files, and other app preferences.
- Keep the old app installed and export a backup before any clean installation.
- This feature has not yet been verified on a physical Android device. Build and test the APK before relying on it.
