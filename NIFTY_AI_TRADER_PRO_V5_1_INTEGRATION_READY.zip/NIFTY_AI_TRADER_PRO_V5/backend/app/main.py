from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from .paper import PaperLedger
from .analysis import analyze_closes, ema_crossover_backtest
from .advanced_analysis import analyze_market_context
from .providers.authorized_feed import AuthorizedFeedAdapter
from .providers.nse_mcp import discover_tools, call_readonly_tool

app = FastAPI(title="NIFTY AI TRADER PRO — Read-only Market Intelligence", version="5.0.0")
ledger = PaperLedger(500000)
market_provider = AuthorizedFeedAdapter()

class CloseSeries(BaseModel):
    close_prices: list[float] = Field(min_length=1, max_length=10000)

class CandleSeries(BaseModel):
    high: list[float] = Field(min_length=2, max_length=10000)
    low: list[float] = Field(min_length=2, max_length=10000)
    close: list[float] = Field(min_length=2, max_length=10000)
    volume: list[float] | None = Field(default=None, max_length=10000)

class BacktestRequest(BaseModel):
    close_prices: list[float] = Field(min_length=30, max_length=10000)
    fee_bps: float = Field(default=5.0, ge=0, le=100)

class PaperOrder(BaseModel):
    side: str
    quantity: int = Field(gt=0, le=100000)
    reference_price: float = Field(gt=0)


@app.get("/api/nse/status")
async def nse_public_status():
    """Discover NSE's public read-only educational data tools."""
    return await discover_tools()

@app.post("/api/nse/query")
async def nse_public_query(payload: dict):
    """Call an allowlisted NSE informational tool; never routes orders."""
    server = payload.get("server", "cm_market")
    tool_name = payload.get("tool")
    arguments = payload.get("arguments", {})
    if not isinstance(arguments, dict):
        raise HTTPException(status_code=400, detail="arguments must be an object")
    try:
        return await call_readonly_tool(server, tool_name, arguments)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"NSE data unavailable: {str(exc)[:200]}")

@app.get("/api/health")
async def health():
    return {"status": "ok", "mode": "LIVE_DATA_ARCHITECTURE_PAPER_ONLY",
            "real_orders_enabled": False, "virtual_capital": 500000}

@app.get("/api/providers/status")
async def provider_status():
    return market_provider.status()

@app.get("/api/providers/angel-one")
async def legacy_provider_status():
    # Backward-compatible route; it does not imply an Angel One connection.
    return market_provider.status()

@app.get("/api/market")
async def market():
    return {
        "symbol": "NIFTY",
        "value": None,
        "source": "NO_LIVE_FEED",
        "status": "OFFLINE",
        "read_only": True,
        "note": "Licensed provider connector is not configured. No synthetic value is labelled as live."
    }

@app.websocket("/ws/market")
async def market_stream(websocket: WebSocket):
    # Safe placeholder: does not fabricate ticks. A configured licensed adapter
    # can publish validated quotes here in a later provider-specific deployment.
    await websocket.accept()
    try:
        await websocket.send_json({
            "type": "status",
            "status": "OFFLINE_NOT_CONFIGURED",
            "read_only": True,
            "message": "No licensed provider connector is configured."
        })
        await websocket.close(code=1000)
    except WebSocketDisconnect:
        return


@app.post("/api/analysis/indicators")
async def indicators(data: CloseSeries):
    try:
        return analyze_closes(data.close_prices)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.post("/api/analysis/market-context")
async def market_context(data: CandleSeries):
    try:
        return analyze_market_context(data.high, data.low, data.close, data.volume)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.post("/api/backtest/ema-crossover")
async def backtest(data: BacktestRequest):
    try:
        return ema_crossover_backtest(data.close_prices, data.fee_bps)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/api/paper/ledger")
async def get_ledger():
    return ledger.snapshot()

@app.post("/api/paper/order")
async def paper_order(order: PaperOrder):
    try:
        return ledger.record(order.side, order.quantity, order.reference_price)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    return """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
    <title>NIFTY AI TRADER PRO</title><style>
    body{background:#080d18;color:#e8eefc;font:16px Arial;padding:22px}
    .card{background:#121c2e;border:1px solid #263650;border-radius:14px;padding:16px;margin:12px 0}
    .muted{color:#9aabc7}.warn{color:#f5c76b}
    </style></head><body><h1>NIFTY AI TRADER PRO</h1>
    <p class='warn'>₹5,00,000 VIRTUAL CAPITAL • PAPER MODE ONLY</p>
    <div class='card'><h3>Angel One Provider</h3><p id='provider' class='muted'>Loading…</p></div>
    <div class='card'><h3>Market feed</h3><p id='market' class='muted'>Loading…</p></div>
    <div class='card'><h3>Virtual portfolio</h3><p id='ledger' class='muted'>Loading…</p></div>
    <script>async function load(){let p=await(await fetch('/api/providers/status')).json();
    document.getElementById('provider').textContent=p.message;
    let m=await(await fetch('/api/market')).json();document.getElementById('market').textContent=m.note;
    let l=await(await fetch('/api/paper/ledger')).json();document.getElementById('ledger').textContent='Virtual balance ₹'+l.virtual_balance+' | Records '+l.orders.length;}
    load();</script></body></html>"""
