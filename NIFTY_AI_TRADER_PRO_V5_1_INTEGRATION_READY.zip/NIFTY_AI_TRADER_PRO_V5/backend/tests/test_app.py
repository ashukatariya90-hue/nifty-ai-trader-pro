from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_is_paper_only():
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["real_orders_enabled"] is False
    assert r.json()["virtual_capital"] == 500000

def test_angel_one_placeholder_is_not_connected():
    r = client.get("/api/providers/angel-one")
    assert r.status_code == 200
    assert r.json()["connected"] is False

def test_market_does_not_claim_live_data():
    r = client.get("/api/market")
    assert r.json()["value"] is None

def test_paper_order():
    r = client.post("/api/paper/order", json={"side":"BUY","quantity":1,"reference_price":100})
    assert r.status_code == 200
    assert r.json()["status"] == "SIMULATED_ONLY"


def test_indicator_analysis_is_not_trade_signal():
    prices = [100 + i * 0.4 for i in range(30)]
    r = client.post("/api/analysis/indicators", json={"close_prices": prices})
    assert r.status_code == 200
    assert r.json()["is_trade_signal"] is False
    assert r.json()["ema_9"] is not None


def test_backtest_requires_enough_data_and_lags_signals():
    prices = [100 + i * 0.2 for i in range(40)]
    r = client.post("/api/backtest/ema-crossover", json={"close_prices": prices})
    assert r.status_code == 200
    assert "bar t" in r.json()["lookahead_control"]
    assert r.json()["is_investment_advice"] is False


def test_rsi_uses_wilder_smoothing():
    from app.analysis import rsi_value
    # 15 consecutive gains: Wilder RSI must be 100, including its zero-loss edge case.
    assert rsi_value([100 + i for i in range(15)], 14) == 100.0
    # Flat prices have no gains or losses and are defined as neutral RSI 50.
    assert rsi_value([100.0] * 15, 14) == 50.0



def test_nse_status_reports_informational_mode(monkeypatch):
    async def fake_discover():
        return {"provider": "NSE public MCP", "mode": "EDUCATIONAL_INFORMATIONAL",
                "delay": "approximately 1–3 minutes", "real_time_trading": False,
                "commercial_use": False, "tools": {"cm_market": []}}
    monkeypatch.setattr("app.main.discover_tools", fake_discover)
    r = client.get("/api/nse/status")
    assert r.status_code == 200
    assert r.json()["provider"] == "NSE public MCP"
    assert r.json()["real_time_trading"] is False

def test_nse_query_rejects_non_allowlisted_tool():
    r = client.post("/api/nse/query", json={"server": "cm_market",
        "tool": "place_order", "arguments": {}})
    assert r.status_code == 400

def test_nse_query_validates_server():
    r = client.post("/api/nse/query", json={"server": "unknown",
        "tool": "get_market_breadth", "arguments": {}})
    assert r.status_code == 503 or r.status_code == 400

def test_advanced_market_context_is_descriptive_only():
    highs = [101 + i * 0.5 for i in range(60)]
    lows = [99 + i * 0.5 for i in range(60)]
    closes = [100 + i * 0.5 for i in range(60)]
    r = client.post("/api/analysis/market-context", json={"high": highs, "low": lows, "close": closes})
    assert r.status_code == 200
    body = r.json()
    assert body["is_trade_signal"] is False
    assert body["ema_50"] is not None
    assert body["macd"] is not None
    assert body["recent_range_reference"]["support_zone_reference"] is not None
    assert body["news_sentiment"] == "NOT_CONNECTED"


def test_advanced_context_rejects_invalid_candles():
    r = client.post("/api/analysis/market-context", json={"high": [99, 100], "low": [101, 99], "close": [100, 99]})
    assert r.status_code == 400

def test_provider_status_never_claims_unconfigured_feed_is_live():
    body = client.get("/api/providers/status").json()
    assert body["connected"] is False
    assert body["mode"] == "OFFLINE_NOT_CONFIGURED"
    assert body["read_only"] is True
    assert body["real_orders_enabled"] is False


def test_advanced_context_calculates_vwap_only_with_volume():
    highs = [102.0, 103.0, 104.0]
    lows = [100.0, 101.0, 102.0]
    closes = [101.0, 102.0, 103.0]
    no_volume = client.post("/api/analysis/market-context", json={"high": highs, "low": lows, "close": closes})
    assert no_volume.status_code == 200
    assert no_volume.json()["vwap"] is None
    with_volume = client.post("/api/analysis/market-context", json={"high": highs, "low": lows, "close": closes, "volume": [10, 20, 30]})
    assert with_volume.status_code == 200
    assert with_volume.json()["vwap"] is not None
    assert with_volume.json()["data_basis"] == "CALLER_SUPPLIED_HISTORICAL_OHLCV"


def test_advanced_context_rejects_mismatched_volume():
    r = client.post("/api/analysis/market-context", json={"high": [102, 103], "low": [100, 101], "close": [101, 102], "volume": [10]})
    assert r.status_code == 400
