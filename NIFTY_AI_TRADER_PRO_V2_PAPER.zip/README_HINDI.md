# NIFTY AI TRADER PRO — Version 2.0

## Included screens
- Home dashboard with ₹5,00,000 virtual starting capital
- Signals/indicator status (EMA, RSI, VWAP are not fabricated when no verified feed is connected)
- Paper tab: create BUY/LONG or SELL/SHORT virtual trades with quantity, assumed entry, stop-loss and target
- Positions tab: review and close virtual positions using an assumed exit price
- History tab: closed virtual trades and calculated P&L

## Important limitations
- PAPER TRADING ONLY. The app does not send orders to Angel One or any broker.
- Angel One adapter is a not-connected placeholder. No live prices are shown.
- Prices typed into paper orders are assumed/manual values, not live quotes.
- The ₹5,00,000 balance is virtual and is not real money.

## Build
The GitHub Actions workflow builds a debug APK. Upload this ZIP to the repository root, replacing the previous ZIP, then commit. The workflow extracts the ZIP and builds `app-debug.apk`.
