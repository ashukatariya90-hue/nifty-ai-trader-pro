package com.example.niftyaitrader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HomeScreen() }
    }
}

@Composable
private fun HomeScreen() {
    val bg = Color(0xFF080D18)
    val panel = Color(0xFF121C2E)
    MaterialTheme(colorScheme = darkColorScheme(background = bg, surface = panel)) {
        Surface(Modifier.fillMaxSize(), color = bg) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("NIFTY AI TRADER PRO", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("ANGEL ONE ADAPTER • NOT CONNECTED", color = Color(0xFFFFC76B), fontSize = 12.sp)
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("SIMULATION CAPITAL", color = Color(0xFF9AABC7), fontSize = 12.sp)
                        Text("₹5,00,000", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Virtual balance only", color = Color(0xFF9AABC7), fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("MARKET DATA", color = Color(0xFF9AABC7), fontSize = 12.sp)
                        Text("Not connected", color = Color.White, fontSize = 20.sp)
                        Text("No live quote is shown until an authorized feed is configured.", color = Color(0xFF9AABC7), fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("TRADING MODE", color = Color(0xFF9AABC7), fontSize = 12.sp)
                        Text("PAPER ONLY", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("No real broker orders or real-money square-off.", color = Color(0xFF9AABC7), fontSize = 12.sp)
                    }
                }
                Text("Educational indicators: EMA • RSI • VWAP", color = Color(0xFF9AABC7), fontSize = 12.sp)
            }
        }
    }
}
