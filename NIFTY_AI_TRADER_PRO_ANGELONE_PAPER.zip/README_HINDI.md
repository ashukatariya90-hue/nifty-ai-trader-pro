# NIFTY AI TRADER PRO — Angel One Live-data / Paper-trading starter

Configuration: intended provider Angel One; virtual capital ₹5,00,000; live-data architecture + paper trading.

IMPORTANT: This is an educational starter. It does not connect to Angel One yet, does not display fabricated values as live prices, and cannot place real broker orders or automatically square off real positions. The Angel One adapter is an explicit not-configured placeholder. Do not put API keys, PINs, TOTP codes, or passwords in source files or GitHub.

## Backend (Python 3.10+)
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
uvicorn app.main:app --reload
```
Dashboard: http://127.0.0.1:8000 | API docs: http://127.0.0.1:8000/docs

## Android APK using GitHub Actions
1. Create a new empty GitHub repository.
2. Extract this ZIP and upload ALL files/folders from inside it to the repository root. Include the hidden `.github` folder.
3. Commit changes.
4. Actions → Build Android APK → Run workflow.
5. On success, download artifact `NIFTY-AI-TRADER-PRO-debug`, extract it, and install `app-debug.apk`.

The workflow intentionally avoids `android-actions/setup-android`, which was implicated in the earlier sdkmanager package error. It searches the GitHub Ubuntu runner's preinstalled Android SDK. A remote build has not been executed from this package, so success cannot be guaranteed.

## Included
- Kotlin/Jetpack Compose dark Android dashboard
- FastAPI backend and health/market/provider/paper-ledger endpoints
- ₹5,00,000 virtual ledger
- EMA, RSI, VWAP educational calculations
- Angel One adapter placeholder, explicitly disconnected
- GitHub Actions workflow and basic tests

Live market data requires an authorized provider integration using current official provider documentation. Real-money order execution is not included.
