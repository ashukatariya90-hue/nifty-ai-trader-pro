# V7.1.0 automatic paper-ledger migration

- Removes the standalone Backup tab and document-picker export/restore flow.
- On first launch, validates the existing `paper_ledger` SharedPreferences records.
- Writes an internal snapshot and schema marker atomically; keeps the original `positions` and `history` keys unchanged.
- Migration is idempotent and does not replace malformed data with empty defaults.
- Keeps applicationId `com.example.niftyaitrader`; versionCode 72 / versionName 7.1.0.

Android retains app-private SharedPreferences for an in-place update signed with the same key. Uninstalling the old app deletes its private data; this migration cannot restore data from an already-uninstalled installation.
