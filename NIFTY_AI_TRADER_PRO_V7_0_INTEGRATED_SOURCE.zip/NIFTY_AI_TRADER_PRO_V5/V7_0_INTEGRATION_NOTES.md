# V7.0 integrated source (Alpha)

This source is based on the V6.9 persistent paper-ledger project. It retains the V6.9 Android application ID, local paper-ledger implementation, and backend paper-ledger implementation. It adds the V7 setup-level calculation module and `/api/v7/analysis/setup-levels` endpoint.

Android versionCode is 70 and versionName is 7.0.0-alpha1.

Important: this is a source integration, not proof of an in-place install upgrade. The previously installed V6.9 APK was signed with a different certificate from the V7.0 Alpha 1 APK. An in-place update requires the original V6.9 private signing key, which was not retained by the ephemeral GitHub debug-build workflow. Do not uninstall the existing app until its paper data is exported/backed up and a migration is tested.

The V7 setup-level endpoint is a research/paper-analysis reference only. It does not guarantee market direction, fills, targets, or profits. Real broker orders remain disabled.
