from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_is_paper_only():
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["real_orders_enabled"] is False
    assert r.json()["virtual_capital"] == 500000

def test_v5_integration_status_is_read_only():
    r = client.get("/api/v5/integration-status")
    assert r.status_code == 200
    body = r.json()
    assert body["real_orders_enabled"] is False
    assert body["live_data_verified"] is False


def test_angel_one_placeholder_is_not_connected():
    r = client.get("/api/providers/angel-one")
    assert r.status_code == 200
    assert r.json()["connected"] is False

def test_market_does_not_claim_live_data():
    r = client.get("/api/market")
    assert r.json()["value"] is None

def test_paper_order():
    r = client.post("/api/paper/order", json={"side":"BUY","quantity":1,"reference_price":100})
    assert r.status_code == 200
    assert r.json()["status"] == "SIMULATED_ONLY"


def test_indicator_analysis_is_not_trade_signal():
    prices = [100 + i * 0.4 for i in range(30)]
    r = client.post("/api/analysis/indicators", json={"close_prices": prices})
    assert r.status_code == 200
    assert r.json()["is_trade_signal"] is False
    assert r.json()["ema_9"] is not None


def test_backtest_requires_enough_data_and_lags_signals():
    prices = [100 + i * 0.2 for i in range(40)]
    r = client.post("/api/backtest/ema-crossover", json={"close_prices": prices})
    assert r.status_code == 200
    assert "bar t" in r.json()["lookahead_control"]
    assert r.json()["is_investment_advice"] is False


def test_rsi_uses_wilder_smoothing():
    from app.analysis import rsi_value
    # 15 consecutive gains: Wilder RSI must be 100, including its zero-loss edge case.
    assert rsi_value([100 + i for i in range(15)], 14) == 100.0
    # Flat prices have no gains or losses and are defined as neutral RSI 50.
    assert rsi_value([100.0] * 15, 14) == 50.0



def test_nse_status_reports_informational_mode(monkeypatch):
    async def fake_discover():
        return {"provider": "NSE public MCP", "mode": "EDUCATIONAL_INFORMATIONAL",
                "delay": "approximately 1–3 minutes", "real_time_trading": False,
                "commercial_use": False, "tools": {"cm_market": []}}
    monkeypatch.setattr("app.main.discover_tools", fake_discover)
    r = client.get("/api/nse/status")
    assert r.status_code == 200
    assert r.json()["provider"] == "NSE public MCP"
    assert r.json()["real_time_trading"] is False

def test_nse_query_rejects_non_allowlisted_tool():
    r = client.post("/api/nse/query", json={"server": "cm_market",
        "tool": "place_order", "arguments": {}})
    assert r.status_code == 400

def test_nse_query_validates_server():
    r = client.post("/api/nse/query", json={"server": "unknown",
        "tool": "get_market_breadth", "arguments": {}})
    assert r.status_code == 503 or r.status_code == 400

def test_advanced_market_context_is_descriptive_only():
    highs = [101 + i * 0.5 for i in range(60)]
    lows = [99 + i * 0.5 for i in range(60)]
    closes = [100 + i * 0.5 for i in range(60)]
    r = client.post("/api/analysis/market-context", json={"high": highs, "low": lows, "close": closes})
    assert r.status_code == 200
    body = r.json()
    assert body["is_trade_signal"] is False
    assert body["ema_50"] is not None
    assert body["macd"] is not None
    assert body["recent_range_reference"]["support_zone_reference"] is not None
    assert body["news_sentiment"] == "NOT_CONNECTED"


def test_advanced_context_rejects_invalid_candles():
    r = client.post("/api/analysis/market-context", json={"high": [99, 100], "low": [101, 99], "close": [100, 99]})
    assert r.status_code == 400

def test_provider_status_never_claims_unconfigured_feed_is_live():
    body = client.get("/api/providers/status").json()
    assert body["connected"] is False
    assert body["mode"] == "OFFLINE_NOT_CONFIGURED"
    assert body["read_only"] is True
    assert body["real_orders_enabled"] is False


def test_advanced_context_calculates_vwap_only_with_volume():
    highs = [102.0, 103.0, 104.0]
    lows = [100.0, 101.0, 102.0]
    closes = [101.0, 102.0, 103.0]
    no_volume = client.post("/api/analysis/market-context", json={"high": highs, "low": lows, "close": closes})
    assert no_volume.status_code == 200
    assert no_volume.json()["vwap"] is None
    with_volume = client.post("/api/analysis/market-context", json={"high": highs, "low": lows, "close": closes, "volume": [10, 20, 30]})
    assert with_volume.status_code == 200
    assert with_volume.json()["vwap"] is not None
    assert with_volume.json()["data_basis"] == "CALLER_SUPPLIED_HISTORICAL_OHLCV"


def test_advanced_context_rejects_mismatched_volume():
    r = client.post("/api/analysis/market-context", json={"high": [102, 103], "low": [100, 101], "close": [101, 102], "volume": [10]})
    assert r.status_code == 400


def test_historical_csv_endpoint_validates_and_analyzes_ohlcv():
    rows = ["Date,Open,High,Low,Close,Volume"]
    for i in range(60):
        close = 100 + i * 0.25
        rows.append(f"2026-01-{(i%28)+1:02d}T00:{i//28:02d}:00,{close-0.2},{close+1},{close-1},{close},1000")
    # Use monotonically increasing ISO timestamps for deterministic validation.
    rows = ["Date,Open,High,Low,Close,Volume"] + [
        f"2026-01-01T00:{i:02d}:00,{100+i*.25:.2f},{101+i*.25:.2f},{99+i*.25:.2f},{100+i*.25:.2f},1000" for i in range(60)
    ]
    response = client.post("/api/analysis/csv", content="\n".join(rows), headers={"content-type": "text/csv"})
    assert response.status_code == 200
    body = response.json()
    assert body["data_quality"]["rows"] == 60
    assert body["ema_50"] is not None
    assert body["macd_signal_9"] is not None
    assert body["vwap"] is not None
    assert body["is_trade_signal"] is False


def test_historical_csv_rejects_bad_ohlc_and_nonascending_dates():
    bad_ohlc = "Date,Open,High,Low,Close,Volume\n2026-01-01,100,99,98,100,10\n2026-01-02,100,102,99,101,10"
    r = client.post("/api/analysis/csv", content=bad_ohlc, headers={"content-type": "text/csv"})
    assert r.status_code == 400
    bad_dates = "Date,Open,High,Low,Close,Volume\n2026-01-02,100,102,99,101,10\n2026-01-01,101,103,100,102,10"
    r = client.post("/api/analysis/csv", content=bad_dates, headers={"content-type": "text/csv"})
    assert r.status_code == 400


def test_current_integration_status_is_explicitly_offline():
    r = client.get("/api/v5/integration-status")
    assert r.status_code == 200
    body = r.json()
    assert body["app_version"] == "6.7.0"
    assert body["live_data_verified"] is False
    assert body["real_orders_enabled"] is False
    assert body["angel_one"]["connected"] is False

def test_news_sentiment_provider_is_not_configured():
    r = client.get("/api/news-sentiment/status")
    assert r.status_code == 200
    assert r.json()["connected"] is False

def test_normalized_market_event_validation():
    r = client.post("/api/market/validate-event", json={
        "symbol": "NIFTY", "last_price": 22000,
        "exchange_timestamp": "2026-11-18T09:15:00+05:30"
    })
    assert r.status_code == 200
    assert r.json()["valid"] is True
    assert r.json()["read_only"] is True
    assert "not a connected live feed" in r.json()["note"]

def test_market_event_rejects_invalid_price():
    r = client.post("/api/market/validate-event", json={
        "symbol": "NIFTY", "last_price": -1,
        "exchange_timestamp": "2026-11-18T09:15:00+05:30"
    })
    assert r.status_code == 400


def test_latest_market_endpoint_is_explicitly_offline_without_provider_events():
    r = client.get("/api/market/latest")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "OFFLINE_NO_EVENTS"
    assert body["events"] == {}
    assert body["read_only"] is True
    assert body["real_orders_enabled"] is False


def test_market_stream_rejects_out_of_order_events():
    import asyncio
    from datetime import datetime, timedelta, timezone
    from app.providers.contracts import parse_tick
    from app.providers.stream_manager import MarketStreamManager

    manager = MarketStreamManager()
    now = datetime.now(timezone.utc)
    newer = parse_tick({"symbol": "NIFTY", "last_price": 22010,
                        "exchange_timestamp": now.isoformat()}, "TEST", received_at=now)
    older = parse_tick({"symbol": "NIFTY", "last_price": 22000,
                        "exchange_timestamp": (now - timedelta(seconds=1)).isoformat()}, "TEST", received_at=now)
    assert asyncio.run(manager.publish(newer)) is True
    assert asyncio.run(manager.publish(older)) is False
    snapshot = manager.latest_snapshot("NIFTY")
    assert snapshot["events"]["NIFTY"]["last_price"] == 22010


def test_market_tick_rejects_far_future_exchange_timestamp():
    from datetime import datetime, timedelta, timezone
    from app.providers.contracts import parse_tick
    future = datetime.now(timezone.utc) + timedelta(minutes=3)
    try:
        parse_tick({"symbol": "NIFTY", "last_price": 22000,
                    "exchange_timestamp": future.isoformat()}, "TEST")
        assert False, "future timestamp should be rejected"
    except ValueError as exc:
        assert "future" in str(exc)


def test_simulation_snapshot_is_synthetic_and_paper_only():
    response = client.get("/api/simulation/snapshot")
    assert response.status_code == 200
    body = response.json()
    assert body["symbol"] == "NIFTY"
    assert body["data_type"] == "SYNTHETIC_NOT_MARKET_DATA"
    assert body["read_only"] is True
    assert body["real_orders_enabled"] is False


def test_simulation_historical_sample_is_synthetic_and_has_ohlcv():
    response = client.get("/api/simulation/historical-sample?count=80")
    assert response.status_code == 200
    body = response.json()
    assert body["data_type"] == "SYNTHETIC_NOT_HISTORICAL_MARKET_DATA"
    assert len(body["candles"]) == 80
    assert all({"open", "high", "low", "close", "volume"} <= set(c) for c in body["candles"])
    assert body["real_orders_enabled"] is False


def test_simulation_historical_sample_rejects_invalid_count():
    response = client.get("/api/simulation/historical-sample?count=10")
    assert response.status_code == 400


def test_v6_research_endpoints_accept_synthetic_integration_sample():
    sample = client.get("/api/simulation/historical-sample?count=80")
    assert sample.status_code == 200
    body = sample.json()
    assert body["data_type"] == "SYNTHETIC_NOT_HISTORICAL_MARKET_DATA"
    candles = body["candles"]
    payload = {
        "high": [c["high"] for c in candles],
        "low": [c["low"] for c in candles],
        "close": [c["close"] for c in candles],
        "volume": [c["volume"] for c in candles],
    }
    assert client.post("/api/analysis/market-context", json=payload).status_code == 200
    multi = client.post("/api/analysis/multi-factor", json=payload)
    assert multi.status_code == 200
    assert multi.json()["paper_only"] is True
    rows = [{
        "timestamp": c["date"], "open": c["open"], "high": c["high"],
        "low": c["low"], "close": c["close"], "volume": c["volume"]
    } for c in candles]
    validation = client.post("/api/analysis/validate-dataset", json={"rows": rows, "interval_seconds": 300})
    assert validation.status_code == 200
    assert validation.json()["valid"] is True
    walk = client.post("/api/research/walk-forward", json={"close_prices": payload["close"], "min_history": 30})
    assert walk.status_code == 200
    assert walk.json()["is_trade_signal"] is False


def test_v61_historical_csv_research_endpoint_returns_full_pipeline():
    from datetime import datetime, timedelta, timezone
    rows = ["Date,Open,High,Low,Close,Volume"]
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    for i in range(60):
        close = 25000 + i * 1.2
        stamp = (start + timedelta(minutes=5*i)).isoformat()
        rows.append(f"{stamp},{close-1},{close+2},{close-2},{close},{1000+i}")
    response = client.post("/api/research/historical-csv", content="\n".join(rows), headers={"content-type": "text/csv"})
    assert response.status_code == 200
    body = response.json()
    assert body["engine"] == "V6_3_NSE_NATIVE_CSV_RESEARCH"
    assert body["dataset_validation"]["valid"] is True
    assert body["multi_factor"]["classification"] == "DESCRIPTIVE_HISTORICAL_CONTEXT_ONLY"
    assert body["walk_forward"]["is_trade_signal"] is False


def test_v61_historical_csv_endpoint_rejects_short_dataset():
    rows = ["Date,Open,High,Low,Close,Volume"]
    for i in range(10):
        close = 100 + i
        rows.append(f"2026-01-01T00:{i:02d}:00+00:00,{close-1},{close+1},{close-2},{close},100")
    response = client.post("/api/research/historical-csv", content="\n".join(rows), headers={"content-type": "text/csv"})
    assert response.status_code == 400
    assert "at least 50" in response.json()["detail"]


def test_historical_csv_accepts_ohlc_without_inventing_volume():
    rows = ["Date,Open,High,Low,Close"]
    from datetime import date, timedelta
    start = date(2026, 8, 1)
    for i in range(56):
        close = 25000 + i * 3
        rows.append(f"{(start + timedelta(days=i)).isoformat()},{close-5},{close+10},{close-10},{close}")
    response = client.post("/api/research/historical-csv", data="\n".join(rows),
                           headers={"content-type": "text/csv"})
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["rows"] == 56
    assert body["volume_available"] is False
    assert body["market_context"]["vwap"] is None
    assert body["multi_factor"]["data_quality"]["volume_available"] is False
    assert body["real_orders_enabled"] is False
    assert body["paper_only"] is True


def test_historical_csv_still_accepts_ohlcv_with_real_volume():
    rows = ["Date,Open,High,Low,Close,Volume"]
    from datetime import date, timedelta
    start = date(2026, 8, 1)
    for i in range(56):
        close = 25000 + i * 3
        rows.append(f"{(start + timedelta(days=i)).isoformat()},{close-5},{close+10},{close-10},{close},123456")
    response = client.post("/api/research/historical-csv", data="\n".join(rows),
                           headers={"content-type": "text/csv"})
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["volume_available"] is True
    assert body["market_context"]["vwap"] is not None


def test_native_nse_index_historical_csv_accepts_newest_first_ohlc():
    from app.historical_research import analyze_historical_csv
    sample = """Index Name,Date,Open,High,Low,Close
NIFTY 50,20 Nov 2026,25368.00,25808.80,25345.20,25800.60
NIFTY 50,19 Nov 2026,25186.80,25514.30,25104.80,25514.30
"""
    # Expand to 50+ daily rows, retaining NSE's original heading and date style.
    from datetime import date, timedelta
    records = []
    start = date(2026, 8, 1)
    for i in range(56):
        close = 24000 + i * 4
        d = start + timedelta(days=i)
        records.append(f"NIFTY 50,{d.strftime('%d %b %Y')},{close-5},{close+10},{close-10},{close}")
    records.reverse()
    csv_text = "Index Name,Date,Open,High,Low,Close" + chr(10) + chr(10).join(records)
    result = analyze_historical_csv(csv_text)
    assert result["engine"] == "V6_3_NSE_NATIVE_CSV_RESEARCH"
    assert result["rows"] == 56
    assert result["volume_available"] is False
    assert result["first_timestamp"].startswith("2026-08-01")
    assert result["last_timestamp"].startswith("2026-09-25")
    assert result["market_context"]["vwap"] is None
    assert result["real_orders_enabled"] is False


def _replay_csv(rows=50):
    from datetime import datetime, timedelta, timezone
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    lines = ["Date,Open,High,Low,Close"]
    for i in range(rows):
        close = 25000 + i
        stamp = (start + timedelta(minutes=5*i)).isoformat()
        lines.append(f"{stamp},{close-1},{close+2},{close-2},{close}")
    return "\n".join(lines)


def test_historical_replay_endpoint_starts_and_labels_replay():
    response = client.post("/api/replay/historical-csv?interval_ms=50",
        content=_replay_csv(), headers={"content-type": "text/csv"})
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "RUNNING"
    assert body["total"] == 50
    assert body["classification"] == "HISTORICAL_REPLAY_NOT_LIVE"
    assert body["real_orders_enabled"] is False
    status = client.get(f"/api/replay/{body['replay_id']}")
    assert status.status_code == 200
    assert status.json()["source"] == "USER_SUPPLIED_HISTORICAL_CSV"


def test_historical_replay_rejects_too_fast_interval():
    response = client.post("/api/replay/historical-csv?interval_ms=1",
        content=_replay_csv(), headers={"content-type": "text/csv"})
    assert response.status_code == 400


def test_historical_replay_publishes_explicitly_delayed_stream_events():
    import time
    response = client.post("/api/replay/historical-csv?interval_ms=50",
        content=_replay_csv(), headers={"content-type": "text/csv"})
    assert response.status_code == 200
    time.sleep(0.12)
    snapshot = client.get("/api/market/latest?symbol=NIFTY").json()
    event = snapshot["events"].get("NIFTY")
    assert event is not None
    assert event["source"] == "HISTORICAL_CSV_REPLAY"
    assert event["freshness"] == "DELAYED"
    assert event["read_only"] is True
    assert snapshot["real_orders_enabled"] is False


def test_v66_diagnostics_reports_read_only_stream_metrics():
    response = client.get("/api/v6/diagnostics")
    assert response.status_code == 200
    body = response.json()
    assert body["app_version"] == "6.7.0"
    assert body["mode"] == "EDUCATIONAL_PAPER_ONLY"
    assert body["real_orders_enabled"] is False
    assert body["live_data_verified"] is False
    assert "metrics" in body["stream"]
    assert body["provider_connections"]["angel_one"]["connected"] is False


def test_stream_diagnostics_count_accepted_and_out_of_order_events():
    import asyncio
    from datetime import datetime, timedelta, timezone
    from app.providers.contracts import parse_tick
    from app.providers.stream_manager import MarketStreamManager

    manager = MarketStreamManager()
    now = datetime.now(timezone.utc)
    newer = parse_tick({"symbol": "NIFTY", "last_price": 22010,
                        "exchange_timestamp": now.isoformat()}, "TEST", received_at=now)
    older = parse_tick({"symbol": "NIFTY", "last_price": 22000,
                        "exchange_timestamp": (now - timedelta(seconds=1)).isoformat()}, "TEST", received_at=now)
    assert asyncio.run(manager.publish(newer)) is True
    assert asyncio.run(manager.publish(older)) is False
    status = manager.status()
    assert status["metrics"]["accepted_events"] == 1
    assert status["metrics"]["rejected_out_of_order_events"] == 1
    assert status["last_event"]["source"] == "TEST"
    assert status["real_orders_enabled"] is False



def test_v67_stream_health_is_read_only_and_explicit_about_provider_state():
    response = client.get("/api/v6/stream-health")
    assert response.status_code == 200
    body = response.json()
    assert body["app_version"] == "6.7.0"
    assert body["stream_status"] in {"OFFLINE_NO_EVENTS", "AVAILABLE"}
    assert body["provider_connected"] is False
    assert body["live_data_verified"] is False
    assert body["read_only"] is True
    assert body["real_orders_enabled"] is False
    assert body["heartbeat_interval_seconds"] == 20


def test_v67_diagnostics_exposes_heartbeat_metric():
    body = client.get("/api/v6/diagnostics").json()
    assert body["app_version"] == "6.7.0"
    assert "heartbeat_messages_sent" in body["stream"]["metrics"]
    assert body["real_orders_enabled"] is False
